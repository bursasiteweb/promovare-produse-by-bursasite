# Promovare produse by BursaSite

Un widget WordPress pentru afișarea produselor WooCommerce cu rotație automată și animație.

---

## Descriere

Acest widget afișează produse dintr-un magazin WooCommerce cu rotație automată și animație. Este perfect pentru promovarea produselor într-un mod dinamic și atractiv.

---

## Caracteristici

- **Rotație automată**: Produsele se rotesc automat la un interval de timp setat.
- **Animație**: Efecte de animație pentru tranziția între produse.
- **Personalizare titlu**:
  - Culoare text și fundal.
  - Dimensiune font.
  - Rotunjire colțuri fundal.
  - Aliniere text (stânga, centru, dreapta).
- **Personalizare preț**:
  - Culoare text și fundal.
  - Dimensiune font.
  - Stil font (normal, bold, italic).
  - Rotunjire colțuri fundal.
  - Spațiere sus și jos.
- **Umbră produs**:
  - Activare/dezactivare umbră.
  - Setare culoare și dimensiune umbră.
- **Lazy loading**: Încărcare lentă a imaginilor pentru performanță optimă.
- **Tracker ID**: Adăugare ID de tracking pentru Google Analytics.
- **Eliberare cache**: Buton pentru golirea manuală a cache-ului.

---

## Instalare

1. Descarcă fișierul `promovare-produse-by-bursasite.zip`.
2. În panoul de administrare WordPress, navighează la **Pluginuri > Adaugă nou**.
3. Apasă pe butonul **Încarcă plugin** și selectează fișierul `promovare-produse-by-bursasite.zip`.
4. Apasă pe **Instalează acum** și apoi activează plugin-ul.

---

## Utilizare

1. După activarea plugin-ului, navighează la **Aspect > Widgets**.
2. Găsește widget-ul **Promovare produse by BursaSite** și trage-l în zona dorită.
3. Configurează setările widget-ului:
   - **Titlu widget**: Titlul afișat deasupra produselor.
   - **Număr produse**: Numărul de produse afișate.
   - **Timp rotație**: Intervalul de timp între rotații (în secunde).
   - **Animație**: Activează sau dezactivează animația.
   - **Afișează titlul produsului**: Afișează sau ascunde titlul produsului.
   - **Afișează prețul produsului**: Afișează sau ascunde prețul produsului.
   - **Personalizare titlu**: Setează culoarea textului, fundalul, dimensiunea fontului, rotunjirea colțurilor și alinierea textului.
   - **Personalizare preț**: Setează culoarea textului, fundalul, dimensiunea fontului, stilul fontului, rotunjirea colțurilor și spațierea.
   - **Umbră produs**: Activează sau dezactivează umbra și setează culoarea și dimensiunea acesteia.
   - **Lazy loading**: Activează sau dezactivează încărcarea lentă a imaginilor.
   - **Tracker ID**: Introdu ID-ul de tracking pentru Google Analytics.
   - **Expirare cache**: Setează timpul de expirare al cache-ului (în minute).
   - **API Sites**: Configurează URL-urile magazinelor și cheile API pentru a prelua produsele.
4. Apasă pe **Salvează** pentru a aplica setările.

---

## Capturi de ecran

1. **Panoul de administrare al widget-ului**:
   ![Panou administrare widget](screenshots/admin-widget.png)

2. **Widget-ul afișat pe site**:
   ![Widget afișat pe site](screenshots/frontend-widget.png)

---

## Suport

Dacă întâmpini probleme sau ai întrebări, te rog să deschizi un tichet pe [GitHub](https://github.com/bursasite/promovare-produse-by-bursasite/issues) sau să contactezi echipa BursaSite la [support@bursasite.ro](mailto:support@bursasite.ro).

---

## Licență

Acest plugin este lansat sub licența [GPLv2](https://www.gnu.org/licenses/gpl-2.0.html).

---

## Versiuni

- **1.0**: Lansare inițială.
- **2.0**: Adăugare opțiuni de personalizare titlu și preț.
- **3.0**: Adăugare umbră produs și lazy loading.
- **4.0**: Adăugare activare/dezactivare umbră și îmbunătățiri generale.

---

## Contribuții

Contribuțiile sunt binevenite! Te rog să deschizi un Pull Request pe [GitHub](https://github.com/bursasite/promovare-produse-by-bursasite/pulls).

---

## Mulțumiri

Mulțumim că folosești **Promovare produse by BursaSite**! Sperăm că îți face plăcere să-l folosești.
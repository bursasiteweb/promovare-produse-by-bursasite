<?php
/**
 * Plugin Name: Promovare produse by BursaSite
 * Description: Un widget WordPress pentru afișarea produselor WooCommerce cu rotație automată și animație.
 * Version: 4.0
 * Author: BursaSite
 * Author URI: https://bursasite.ro/
 */

if (!defined('ABSPATH')) {
    exit;
}

class Wallsign_Product_Widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'wallsign_product_widget',
            __('Promovare produse by BursaSite', 'text_domain'),
            array('description' => __('Afișează produse dintr-un magazin WooCommerce cu animație.', 'text_domain'))
        );

        // Încarcă scripturile și stilurile
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_post_clear_wallsign_cache', array($this, 'clear_cache'));
    }

    public function enqueue_scripts() {
        wp_enqueue_style('wallsign-styles', plugin_dir_url(__FILE__) . 'css/styles.css');
        wp_enqueue_script('wallsign-rotation', plugin_dir_url(__FILE__) . 'js/rotation.js', array(), '1.0', true);
        wp_script_add_data('wallsign-rotation', 'defer', true); // Adaugă atributul defer
    }

    public function widget($args, $instance) {
        $num_products = !empty($instance['num_products']) ? (int) $instance['num_products'] : 10;
        $rotation_speed = !empty($instance['rotation_speed']) ? (int) $instance['rotation_speed'] * 1000 : 10000;
        $api_sites = !empty($instance['api_sites']) ? $instance['api_sites'] : [];
        $widget_title = !empty($instance['widget_title']) ? $instance['widget_title'] : '';
        $enable_animation = isset($instance['enable_animation']) ? (bool) $instance['enable_animation'] : true;
        $show_title = isset($instance['show_title']) ? (bool) $instance['show_title'] : true;
        $show_price = isset($instance['show_price']) ? (bool) $instance['show_price'] : true;
        $price_alignment = !empty($instance['price_alignment']) ? $instance['price_alignment'] : 'center';
        $price_background = !empty($instance['price_background']) ? $instance['price_background'] : '#ffffff';
        $price_text_size = !empty($instance['price_text_size']) ? $instance['price_text_size'] : '14px';
        $price_text_color = !empty($instance['price_text_color']) ? $instance['price_text_color'] : '#000000';
        $price_font_style = !empty($instance['price_font_style']) ? $instance['price_font_style'] : 'normal';
        $price_padding_top = !empty($instance['price_padding_top']) ? $instance['price_padding_top'] : 0;
        $price_padding_bottom = !empty($instance['price_padding_bottom']) ? $instance['price_padding_bottom'] : 0;
        $price_border_radius = !empty($instance['price_border_radius']) ? $instance['price_border_radius'] : '0';
        $shadow_enabled = isset($instance['shadow_enabled']) ? (bool) $instance['shadow_enabled'] : false;
        $shadow_color = !empty($instance['shadow_color']) ? $instance['shadow_color'] : '#CC0000';
        $shadow_size = !empty($instance['shadow_size']) ? $instance['shadow_size'] : '5';
        $title_text_color = !empty($instance['title_text_color']) ? $instance['title_text_color'] : '#000000';
        $title_background_color = !empty($instance['title_background_color']) ? $instance['title_background_color'] : '';
        $title_font_size = !empty($instance['title_font_size']) ? $instance['title_font_size'] : '16px';
        $title_border_radius = !empty($instance['title_border_radius']) ? $instance['title_border_radius'] : '0';
        $title_alignment = !empty($instance['title_alignment']) ? $instance['title_alignment'] : 'center';
        $image_format = !empty($instance['image_format']) ? $instance['image_format'] : '1_1';
        $lazy_loading = isset($instance['lazy_loading']) ? (bool) $instance['lazy_loading'] : true;
        $tracker_id = !empty($instance['tracker_id']) ? $instance['tracker_id'] : '';

        echo $args['before_widget'];
        if (!empty($widget_title)) {
            echo $args['before_title'] . '<div class="widget-title" style="
                color: ' . esc_attr($title_text_color) . ';
                background-color: ' . esc_attr($title_background_color) . ';
                font-size: ' . esc_attr($title_font_size) . ';
                border-radius: ' . esc_attr($title_border_radius) . 'px;
                text-align: ' . esc_attr($title_alignment) . ';
                padding: 10px; /* Adaugă padding pentru aspect mai plăcut */
            ">' . esc_html($widget_title) . '</div>' . $args['after_title'];
        }
        echo '<div id="wallsign-products-container" class="wallsign-products">';
        echo '<div id="wallsign-product-list" class="product-list">';

        $products = [];
        foreach ($api_sites as $site) {
            if (!empty($site['url']) && !empty($site['consumer_key']) && !empty($site['consumer_secret'])) {
                $products = array_merge($products, $this->fetch_products($site['url'], $num_products, $site['consumer_key'], $site['consumer_secret']));
            }
        }
        shuffle($products);
        $products = array_slice($products, 0, $num_products);

        if (!empty($products)) {
            echo '<div class="product-row">';
            foreach ($products as $index => $product) {
                if ($index % 2 === 0 && $index !== 0) {
                    echo '</div><div class="product-row">';
                }
                $shadow_style = $shadow_enabled ? 'box-shadow: 0 0 ' . esc_attr($shadow_size) . 'px ' . esc_attr($shadow_color) . ';' : '';
                echo '<div class="product-item" style="' . $shadow_style . '">';
                $product_link = esc_url($product['link']) . (empty($tracker_id) ? '' : '?utm_source=' . esc_attr($tracker_id));
                echo '<a href="' . $product_link . '" target="_blank">';
                echo '<img src="' . esc_url($product['image']) . '" alt="' . esc_attr($product['title']) . '" loading="' . ($lazy_loading ? 'lazy' : 'eager') . '">';
                if ($show_title) {
                    echo '<p class="product-title">' . esc_html($product['title']) . '</p>';
                }
                if ($show_price) {
                    echo '<p class="product-price" style="
                        background-color: ' . esc_attr($price_background) . ';
                        color: ' . esc_attr($price_text_color) . ';
                        font-size: ' . esc_attr($price_text_size) . ';
                        font-style: ' . esc_attr($price_font_style) . ';
                        text-align: ' . esc_attr($price_alignment) . ';
                        padding-top: ' . esc_attr($price_padding_top) . 'px;
                        padding-bottom: ' . esc_attr($price_padding_bottom) . 'px;
                        border-radius: ' . esc_attr($price_border_radius) . 'px;
                    ">' . esc_html($product['price']) . ' Lei</p>';
                }
                echo '</a>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<p>Nu s-au găsit produse.</p>';
        }

        echo '</div></div>';

        // Adaugă animația doar dacă este activată
        if ($enable_animation) {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    let container = document.getElementById('wallsign-product-list');
                    let speed = {$rotation_speed};
                    setInterval(() => {
                        container.classList.add('fade-out');
                        setTimeout(() => {
                            container.appendChild(container.firstElementChild);
                            container.classList.remove('fade-out');
                        }, 500);
                    }, speed);
                });
            </script>";
        }

        echo $args['after_widget'];
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['num_products'] = !empty($new_instance['num_products']) ? (int) $new_instance['num_products'] : 10;
        $instance['rotation_speed'] = !empty($new_instance['rotation_speed']) ? (int) $new_instance['rotation_speed'] : 10;
        $instance['widget_title'] = !empty($new_instance['widget_title']) ? sanitize_text_field($new_instance['widget_title']) : '';
        $instance['enable_animation'] = isset($new_instance['enable_animation']) ? (bool) $new_instance['enable_animation'] : false;
        $instance['show_title'] = isset($new_instance['show_title']) ? (bool) $new_instance['show_title'] : false;
        $instance['show_price'] = isset($new_instance['show_price']) ? (bool) $new_instance['show_price'] : false;
        $instance['price_alignment'] = !empty($new_instance['price_alignment']) ? sanitize_text_field($new_instance['price_alignment']) : 'center';
        $instance['price_background'] = !empty($new_instance['price_background']) ? sanitize_hex_color($new_instance['price_background']) : '#ffffff';
        $instance['price_text_size'] = !empty($new_instance['price_text_size']) ? sanitize_text_field($new_instance['price_text_size']) : '14px';
        $instance['price_text_color'] = !empty($new_instance['price_text_color']) ? sanitize_hex_color($new_instance['price_text_color']) : '#000000';
        $instance['price_font_style'] = !empty($new_instance['price_font_style']) ? sanitize_text_field($new_instance['price_font_style']) : 'normal';
        $instance['price_padding_top'] = !empty($new_instance['price_padding_top']) ? (int) $new_instance['price_padding_top'] : 0;
        $instance['price_padding_bottom'] = !empty($new_instance['price_padding_bottom']) ? (int) $new_instance['price_padding_bottom'] : 0;
        $instance['price_border_radius'] = !empty($new_instance['price_border_radius']) ? sanitize_text_field($new_instance['price_border_radius']) : '0';
        $instance['shadow_enabled'] = isset($new_instance['shadow_enabled']) ? (bool) $new_instance['shadow_enabled'] : false;
        $instance['shadow_color'] = !empty($new_instance['shadow_color']) ? sanitize_hex_color($new_instance['shadow_color']) : '#CC0000';
        $instance['shadow_size'] = !empty($new_instance['shadow_size']) ? sanitize_text_field($new_instance['shadow_size']) : '5';
        $instance['title_text_color'] = !empty($new_instance['title_text_color']) ? sanitize_hex_color($new_instance['title_text_color']) : '#000000';
        $instance['title_background_color'] = !empty($new_instance['title_background_color']) ? sanitize_hex_color($new_instance['title_background_color']) : '';
        $instance['title_font_size'] = !empty($new_instance['title_font_size']) ? sanitize_text_field($new_instance['title_font_size']) : '16px';
        $instance['title_border_radius'] = !empty($new_instance['title_border_radius']) ? sanitize_text_field($new_instance['title_border_radius']) : '0';
        $instance['title_alignment'] = !empty($new_instance['title_alignment']) ? sanitize_text_field($new_instance['title_alignment']) : 'center';
        $instance['image_format'] = !empty($new_instance['image_format']) ? sanitize_text_field($new_instance['image_format']) : '1_1';
        $instance['lazy_loading'] = isset($new_instance['lazy_loading']) ? (bool) $new_instance['lazy_loading'] : true;
        $instance['tracker_id'] = !empty($new_instance['tracker_id']) ? sanitize_text_field($new_instance['tracker_id']) : '';
        $instance['cache_expiration'] = !empty($new_instance['cache_expiration']) ? (int) $new_instance['cache_expiration'] : 30;
        $instance['api_sites'] = array();

        if (!empty($new_instance['api_sites'])) {
            foreach ($new_instance['api_sites'] as $site) {
                $instance['api_sites'][] = array(
                    'url' => !empty($site['url']) ? esc_url_raw($site['url']) : '',
                    'consumer_key' => !empty($site['consumer_key']) ? sanitize_text_field($site['consumer_key']) : '',
                    'consumer_secret' => !empty($site['consumer_secret']) ? sanitize_text_field($site['consumer_secret']) : '',
                );
            }
        }

        return $instance;
    }

    public function form($instance) {
        $num_products = !empty($instance['num_products']) ? (int) $instance['num_products'] : 10;
        $rotation_speed = !empty($instance['rotation_speed']) ? (int) $instance['rotation_speed'] : 10;
        $widget_title = !empty($instance['widget_title']) ? $instance['widget_title'] : '';
        $enable_animation = isset($instance['enable_animation']) ? (bool) $instance['enable_animation'] : true;
        $show_title = isset($instance['show_title']) ? (bool) $instance['show_title'] : true;
        $show_price = isset($instance['show_price']) ? (bool) $instance['show_price'] : true;
        $price_alignment = !empty($instance['price_alignment']) ? $instance['price_alignment'] : 'center';
        $price_background = !empty($instance['price_background']) ? $instance['price_background'] : '#ffffff';
        $price_text_size = !empty($instance['price_text_size']) ? $instance['price_text_size'] : '14px';
        $price_text_color = !empty($instance['price_text_color']) ? $instance['price_text_color'] : '#000000';
        $price_font_style = !empty($instance['price_font_style']) ? $instance['price_font_style'] : 'normal';
        $price_padding_top = !empty($instance['price_padding_top']) ? $instance['price_padding_top'] : 0;
        $price_padding_bottom = !empty($instance['price_padding_bottom']) ? $instance['price_padding_bottom'] : 0;
        $price_border_radius = !empty($instance['price_border_radius']) ? $instance['price_border_radius'] : '0';
        $shadow_enabled = isset($instance['shadow_enabled']) ? (bool) $instance['shadow_enabled'] : false;
        $shadow_color = !empty($instance['shadow_color']) ? $instance['shadow_color'] : '#CC0000';
        $shadow_size = !empty($instance['shadow_size']) ? $instance['shadow_size'] : '5';
        $title_text_color = !empty($instance['title_text_color']) ? $instance['title_text_color'] : '#000000';
        $title_background_color = !empty($instance['title_background_color']) ? $instance['title_background_color'] : '';
        $title_font_size = !empty($instance['title_font_size']) ? $instance['title_font_size'] : '16px';
        $title_border_radius = !empty($instance['title_border_radius']) ? $instance['title_border_radius'] : '0';
        $title_alignment = !empty($instance['title_alignment']) ? $instance['title_alignment'] : 'center';
        $image_format = !empty($instance['image_format']) ? $instance['image_format'] : '1_1';
        $lazy_loading = isset($instance['lazy_loading']) ? (bool) $instance['lazy_loading'] : true;
        $tracker_id = !empty($instance['tracker_id']) ? $instance['tracker_id'] : '';
        $cache_expiration = !empty($instance['cache_expiration']) ? $instance['cache_expiration'] : 30;
        $api_sites = !empty($instance['api_sites']) ? $instance['api_sites'] : array_fill(0, 10, array('url' => '', 'consumer_key' => '', 'consumer_secret' => ''));

        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_title')); ?>">Titlu Widget:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_title')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('widget_title')); ?>" 
                   type="text" value="<?php echo esc_attr($widget_title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title_text_color')); ?>">Culoare text titlu:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title_text_color')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('title_text_color')); ?>" 
                   type="color" value="<?php echo esc_attr($title_text_color); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title_background_color')); ?>">Culoare fundal titlu:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title_background_color')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('title_background_color')); ?>" 
                   type="color" value="<?php echo esc_attr($title_background_color); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title_font_size')); ?>">Dimensiune font titlu:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title_font_size')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('title_font_size')); ?>" 
                   type="text" value="<?php echo esc_attr($title_font_size); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title_border_radius')); ?>">Rotunjire colțuri fundal titlu (px):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title_border_radius')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('title_border_radius')); ?>" 
                   type="number" min="0" value="<?php echo esc_attr($title_border_radius); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title_alignment')); ?>">Aranjament text titlu:</label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('title_alignment')); ?>" 
                    name="<?php echo esc_attr($this->get_field_name('title_alignment')); ?>">
                <option value="left" <?php selected($title_alignment, 'left'); ?>>Stânga</option>
                <option value="center" <?php selected($title_alignment, 'center'); ?>>Centru</option>
                <option value="right" <?php selected($title_alignment, 'right'); ?>>Dreapta</option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr($this->get_field_id('shadow_enabled')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('shadow_enabled')); ?>" 
                   <?php checked($shadow_enabled); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('shadow_enabled')); ?>">Activează umbra produselor</label>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('shadow_color')); ?>">Culoare umbră produs:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('shadow_color')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('shadow_color')); ?>" 
                   type="color" value="<?php echo esc_attr($shadow_color); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('shadow_size')); ?>">Dimensiune umbră produs (px):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('shadow_size')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('shadow_size')); ?>" 
                   type="number" min="0" value="<?php echo esc_attr($shadow_size); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('num_products')); ?>">Număr produse:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('num_products')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('num_products')); ?>" 
                   type="number" min="1" value="<?php echo esc_attr($num_products); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('rotation_speed')); ?>">Timp rotație (secunde):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('rotation_speed')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('rotation_speed')); ?>" 
                   type="number" min="1" value="<?php echo esc_attr($rotation_speed); ?>">
        </p>
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr($this->get_field_id('enable_animation')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('enable_animation')); ?>" 
                   <?php checked($enable_animation); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('enable_animation')); ?>">Activează animația</label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr($this->get_field_id('show_title')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('show_title')); ?>" 
                   <?php checked($show_title); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('show_title')); ?>">Afișează titlul produsului</label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr($this->get_field_id('show_price')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('show_price')); ?>" 
                   <?php checked($show_price); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('show_price')); ?>">Afișează prețul produsului</label>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_alignment')); ?>">Aranjament preț:</label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('price_alignment')); ?>" 
                    name="<?php echo esc_attr($this->get_field_name('price_alignment')); ?>">
                <option value="left" <?php selected($price_alignment, 'left'); ?>>Stânga</option>
                <option value="center" <?php selected($price_alignment, 'center'); ?>>Centru</option>
                <option value="right" <?php selected($price_alignment, 'right'); ?>>Dreapta</option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_background')); ?>">Culoare fundal preț:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_background')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_background')); ?>" 
                   type="color" value="<?php echo esc_attr($price_background); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_text_size')); ?>">Dimensiune text preț:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_text_size')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_text_size')); ?>" 
                   type="text" value="<?php echo esc_attr($price_text_size); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_text_color')); ?>">Culoare text preț:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_text_color')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_text_color')); ?>" 
                   type="color" value="<?php echo esc_attr($price_text_color); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_font_style')); ?>">Stil font preț:</label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('price_font_style')); ?>" 
                    name="<?php echo esc_attr($this->get_field_name('price_font_style')); ?>">
                <option value="normal" <?php selected($price_font_style, 'normal'); ?>>Normal</option>
                <option value="bold" <?php selected($price_font_style, 'bold'); ?>>Bold</option>
                <option value="italic" <?php selected($price_font_style, 'italic'); ?>>Italic</option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_padding_top')); ?>">Spațiere sus preț (px):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_padding_top')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_padding_top')); ?>" 
                   type="number" min="0" value="<?php echo esc_attr($price_padding_top); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_padding_bottom')); ?>">Spațiere jos preț (px):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_padding_bottom')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_padding_bottom')); ?>" 
                   type="number" min="0" value="<?php echo esc_attr($price_padding_bottom); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('price_border_radius')); ?>">Rotunjire colțuri fundal preț (px):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('price_border_radius')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('price_border_radius')); ?>" 
                   type="number" min="0" value="<?php echo esc_attr($price_border_radius); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('image_format')); ?>">Format imagine:</label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('image_format')); ?>" 
                    name="<?php echo esc_attr($this->get_field_name('image_format')); ?>">
                <option value="1_1" <?php selected($image_format, '1_1'); ?>>1:1 (Pătrat)</option>
                <option value="original" <?php selected($image_format, 'original'); ?>>Original</option>
                <option value="thumbnail" <?php selected($image_format, 'thumbnail'); ?>>Thumbnail</option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr($this->get_field_id('lazy_loading')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('lazy_loading')); ?>" 
                   <?php checked($lazy_loading); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('lazy_loading')); ?>">Activează lazy loading pentru imagini</label>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('tracker_id')); ?>">Tracker ID (Google Analytics):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('tracker_id')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('tracker_id')); ?>" 
                   type="text" value="<?php echo esc_attr($tracker_id); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cache_expiration')); ?>">Expirare cache (minute):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('cache_expiration')); ?>" 
                   name="<?php echo esc_attr($this->get_field_name('cache_expiration')); ?>" 
                   type="number" min="1" value="<?php echo esc_attr($cache_expiration); ?>">
        </p>

        <div class="accordion">
            <?php for ($i = 0; $i < 10; $i++): ?>
                <div class="accordion-item">
                    <h3 class="accordion-title">Site <?php echo $i + 1; ?></h3>
                    <div class="accordion-content">
                        <p>
                            <label for="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_url')); ?>">URL Magazin:</label>
                            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_url')); ?>" 
                                   name="<?php echo esc_attr($this->get_field_name('api_sites')); ?>[<?php echo $i; ?>][url]" 
                                   type="text" value="<?php echo esc_attr($api_sites[$i]['url']); ?>">
                        </p>
                        <p>
                            <label for="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_consumer_key')); ?>">Consumer Key:</label>
                            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_consumer_key')); ?>" 
                                   name="<?php echo esc_attr($this->get_field_name('api_sites')); ?>[<?php echo $i; ?>][consumer_key]" 
                                   type="text" value="<?php echo esc_attr($api_sites[$i]['consumer_key']); ?>">
                        </p>
                        <p>
                            <label for="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_consumer_secret')); ?>">Consumer Secret:</label>
                            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('api_sites_' . $i . '_consumer_secret')); ?>" 
                                   name="<?php echo esc_attr($this->get_field_name('api_sites')); ?>[<?php echo $i; ?>][consumer_secret]" 
                                   type="text" value="<?php echo esc_attr($api_sites[$i]['consumer_secret']); ?>">
                        </p>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <p>
            <a href="<?php echo admin_url('admin-post.php?action=clear_wallsign_cache'); ?>" class="button button-secondary">Eliberare Cache</a>
        </p>
        <?php
    }

    private function fetch_products($url, $num_products, $consumer_key, $consumer_secret) {
        $transient_key = 'wallsign_products_' . md5($url . $num_products . $consumer_key . $consumer_secret);
        $products = get_transient($transient_key);

        if (false === $products) {
            $endpoint = '/wp-json/wc/v3/products';
            $args = array(
                'consumer_key' => $consumer_key,
                'consumer_secret' => $consumer_secret,
                'per_page' => $num_products,
            );

            $response = wp_remote_get($url . $endpoint, array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode($consumer_key . ':' . $consumer_secret),
                ),
            ));

            if (is_wp_error($response)) {
                return [];
            }

            $body = wp_remote_retrieve_body($response);
            $products = json_decode($body, true);

            // Stochează produsele în cache timp de 1 oră
            set_transient($transient_key, $products, HOUR_IN_SECONDS);
        }

        $formatted_products = [];
        foreach ($products as $product) {
            if ($product['price'] == 0 || $product['stock_status'] !== 'instock') {
                continue; // Sari peste produsele cu preț 0 sau care nu sunt în stoc
            }

            $image_url = '';
            if (!empty($product['images'][0]['thumbnail'])) {
                $image_url = $product['images'][0]['thumbnail']; // Folosește thumbnail-ul
            } elseif (!empty($product['images'][0]['src'])) {
                $image_url = $product['images'][0]['src']; // Folosește imaginea full ca fallback
            }

            $formatted_products[] = array(
                'title' => $product['name'],
                'price' => $product['price'],
                'image' => $image_url,
                'link' => $product['permalink'],
            );
        }

        return $formatted_products;
    }

    public function clear_cache() {
        global $wpdb;
        $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_wallsign_products_%'");
        $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_wallsign_products_%'");

        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>Cache-ul a fost eliberat cu succes!</p></div>';
        });

        wp_redirect(wp_get_referer());
        exit;
    }
}

function register_wallsign_product_widget() {
    register_widget('Wallsign_Product_Widget');
}
add_action('widgets_init', 'register_wallsign_product_widget');
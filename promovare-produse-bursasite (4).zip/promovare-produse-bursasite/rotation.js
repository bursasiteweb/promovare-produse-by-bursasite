document.addEventListener('DOMContentLoaded', function() {
    let container = document.getElementById('wallsign-product-list');
    let speed = wallsign_vars.rotation_speed;
    setInterval(() => {
        container.classList.add('fade-out');
        setTimeout(() => {
            container.appendChild(container.firstElementChild);
            container.classList.remove('fade-out');
        }, 500);
    }, speed);
});




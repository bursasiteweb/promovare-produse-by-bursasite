// Tracker pentru comenzile primite
if (!function_exists('log_order_with_utm')) {
    function log_order_with_utm($order_id) {
        if (isset($_GET['utm_source'])) {
            $utm_source = sanitize_text_field($_GET['utm_source']);
            $order = wc_get_order($order_id);
            $order_data = $order->get_data();
            $log_message = sprintf(
                "Comanda #%s primită de la %s. Total: %s. Data: %s\n",
                $order_id,
                $utm_source,
                $order_data['total'],
                date('Y-m-d H:i:s')
            );

            // Salvează log-ul într-un fișier
            $log_file = plugin_dir_path(__FILE__) . 'order_logs.txt';
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }
    }
    add_action('woocommerce_thankyou', 'log_order_with_utm');
}